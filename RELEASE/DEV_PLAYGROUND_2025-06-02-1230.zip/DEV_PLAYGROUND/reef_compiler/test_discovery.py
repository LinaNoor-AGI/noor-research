# test_discovery.py
from discovery import discover_reef_files
from pathlib import Path

reef_list = discover_reef_files(Path("./reef_archives"), skip_broken=True)
for rf in reef_list:
    print(rf.path.name, rf.symbolic_id, rf.blocks)
