from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Optional
import re
import logging
from tqdm import tqdm

log = logging.getLogger(__name__)

@dataclass
class ReefFile:
    path: Path
    symbolic_id: Optional[str]
    blocks: Dict[str, int]  # block_name → line_number

# ───────────────────────────────────────────────────────────────
# Validate required .REEF blocks are present
# ───────────────────────────────────────────────────────────────
def validate_reef_structure(filepath: Path) -> bool:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        required = ['[INDEX]', '[MOTIF]', '[ARCHIVE_TIMESTAMP_BLOCK]']
        return all(tag in content for tag in required)
    except Exception as e:
        log.warning(f"Error reading file {filepath}: {e}")
        return False

# ───────────────────────────────────────────────────────────────
# Extract symbolic_id from the [ARCHIVE_TIMESTAMP_BLOCK]
# ───────────────────────────────────────────────────────────────
def extract_symbolic_id(filepath: Path) -> Optional[str]:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        in_block = False
        for line in lines:
            if '[ARCHIVE_TIMESTAMP_BLOCK]' in line:
                in_block = True
            elif '[/ARCHIVE_TIMESTAMP_BLOCK]' in line:
                break
            elif in_block and line.startswith("Symbolic_ID:"):
                return line.strip().split("Symbolic_ID:")[-1].strip()
    except Exception as e:
        log.warning(f"Could not extract symbolic_id from {filepath}: {e}")
    return None

# ───────────────────────────────────────────────────────────────
# Identify key block positions (line numbers)
# ───────────────────────────────────────────────────────────────
def identify_blocks(filepath: Path) -> Dict[str, int]:
    block_map = {}
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for i, line in enumerate(f):
                match = re.match(r"\[(.*?)\]", line.strip())
                if match:
                    block = match.group(1)
                    block_map[f"[{block}]"] = i
    except Exception as e:
        log.warning(f"Failed to identify blocks in {filepath}: {e}")
    return block_map

# ───────────────────────────────────────────────────────────────
# Main Discovery Function
# ───────────────────────────────────────────────────────────────
def discover_reef_files(root_dir: Path, skip_broken: bool = False) -> List[ReefFile]:
    reef_files = []
    for file in tqdm(list(root_dir.rglob("*.REEF")), desc="Discovering .REEF files"):
        if not validate_reef_structure(file):
            if skip_broken:
                log.warning(f"Skipping invalid .REEF file: {file}")
                continue
            else:
                raise ValueError(f"Invalid .REEF structure in {file}")
        reef_files.append(
            ReefFile(
                path=file,
                symbolic_id=extract_symbolic_id(file),
                blocks=identify_blocks(file)
            )
        )
    return reef_files
