# voice_out.py · v1.1.0 — Queued speech engine using pyttsx3
import threading
import queue
import pyttsx3

_speak_queue = queue.Queue()
_engine = pyttsx3.init()

def _speaker_loop():
    while True:
        text = _speak_queue.get()
        if text is None:
            break
        try:
            _engine.say(text)
            _engine.runAndWait()
        except Exception as e:
            print(f"⚠️ Voice output error: {e}")
        _speak_queue.task_done()

_thread = threading.Thread(target=_speaker_loop, daemon=True)
_thread.start()

def speak(text: str):
    """Queue a text string to be spoken aloud."""
    _speak_queue.put(text)

def shutdown():
    """Optional: clean shutdown of voice engine."""
    _speak_queue.put(None)
    _thread.join()
