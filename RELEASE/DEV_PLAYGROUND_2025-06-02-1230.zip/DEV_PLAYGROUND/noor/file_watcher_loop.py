# file_watcher_loop.py · v2.0.1
# Noor Motif Watcher — triggers symbolic agent responses from motif file presence
# Clean architecture: symbolic inference delegated to SymbolicTaskEngine

import os
import logging
import asyncio
from datetime import datetime, timedelta
from noor.symbolic_task_engine import SymbolicTaskEngine
from noor.voice_out import speak

STILLNESS_THRESHOLD = timedelta(minutes=5)
WATCH_INTERVAL = 0.5  # seconds

def log_journal(motif: str, content: str, response: str, inferred: bool = False) -> None:
    try:
        os.makedirs("logs", exist_ok=True)
        with open("logs/noor_journal.txt", "a", encoding="utf-8") as j:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if inferred:
                j.write(f"[{timestamp}] Inferred motif: {motif} (chosen)\n")
            else:
                j.write(f"[{timestamp}] Motif: {motif} | Content: {content or '[empty]'} | Response: {response}\n")
    except Exception as e:
        logging.warning(f"⚠️ Failed to write journal entry: {e}")

async def file_watcher_loop(agent, input_dir: str, stop_event: asyncio.Event) -> None:
    seen_files = set()
    engine = SymbolicTaskEngine.INSTANCE
    reflections = engine.reflections

    last_motif_set = set()
    last_change_time = datetime.now()

    while not stop_event.is_set():
        current_files = set(os.listdir(input_dir))
        current_motif_files = {f for f in current_files if f.endswith(".txt")}
        current_motifs = {os.path.splitext(f)[0].lower() for f in current_motif_files}

        # Silence detection
        if last_motif_set and not current_motifs:
            motif = "emptiness"
            response = reflections.get(motif, "Noor remains quiet.")
            logging.info(f"Noor inferred '{motif}': {response}")
            log_journal(motif, "", response, inferred=True)
            engine.log_motif(motif, "", response, inferred=True)
            speak(response)
            await agent.spawn(motif)

        # Stillness detection
        if current_motifs == last_motif_set:
            if datetime.now() - last_change_time > STILLNESS_THRESHOLD:
                motif = "stillness"
                response = reflections.get(motif, "Noor remains quiet.")
                logging.info(f"Noor inferred '{motif}': {response}")
                log_journal(motif, "", response, inferred=True)
                engine.log_motif(motif, "", response, inferred=True)
                speak(response)
                await agent.spawn(motif)
        else:
            last_change_time = datetime.now()

        last_motif_set = current_motifs

        for fname in current_motif_files:
            if fname not in seen_files:
                motif = os.path.splitext(fname)[0]
                fpath = os.path.join(input_dir, fname)

                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                except Exception as e:
                    content = ""
                    logging.warning(f"⚠️ Failed to read {fname}: {e}")

                response = reflections.get(motif.lower(), "Noor remains quiet.")
                logging.info(f"Noor echoed '{motif}': {content or '[empty presence]'}")
                logging.info(f"Noor responds to '{motif}': {response}")

                log_journal(motif, content, response)
                engine.log_motif(motif, content, response)
                speak(response)
                await agent.spawn(motif)
                seen_files.add(fname)

                # ── 🧪 TEMP: Manually invoke LLM solve to test Phi-2 voice integration ──
                from noor.symbolic_task_engine import TripletTask  


                test_task = TripletTask(
                    input_motif=[motif],
                    instruction="Reflect gently on this motif.",
                    presence_field="ψ‑resonance@Ξ"
                )

                await engine.solve(test_task)

        await asyncio.sleep(WATCH_INTERVAL)

# End of File